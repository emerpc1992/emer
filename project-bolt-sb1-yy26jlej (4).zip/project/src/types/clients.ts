export interface Client {
  code: string;
  name: string;
  phone: string;
  notes?: string;
}