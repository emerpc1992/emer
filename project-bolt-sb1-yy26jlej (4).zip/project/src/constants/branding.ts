export const BRANDING = {
  name: 'MASTER FACTU',
  slogan: 'TU NEGOCIO EN UN CLICK',
  year: new Date().getFullYear(),
} as const;