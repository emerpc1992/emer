import { User } from '../types/auth';

export const USERS: User[] = [
  {
    username: 'admin',
    password: 'admin',
    role: 'admin',
  },
  {
    username: 'masteradmin',
    password: 'Masterproyec1',
    role: 'admin',
  },
  {
    username: 'user',
    password: 'user',
    role: 'user',
  },
];